package com.example.hector.ad3a;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RegistroAsignaturas extends AppCompatActivity {
    private Button regis;
    private EditText as_nombre;
    private EditText as_alumn;
    private MyDBAdapter dbAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_asignaturas);

        regis=(Button) findViewById(R.id.reg);
        as_nombre=(EditText) findViewById(R.id.nombre_as);
        as_alumn=(EditText) findViewById(R.id.as_alumn);
        dbAdapter = new MyDBAdapter(this);
        regis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbAdapter.open();
                dbAdapter.insertarAsignatura(as_nombre.getText().toString(),as_alumn.getText().toString());
            }
        });


    }
}
